<?php

return array(
    //Labels of registration form fields
    'name' => 'Nombre(s)',
    'surname' => 'Apellido(s)',
    'e-mail' => 'Correo electrónico',
    'password' => 'Contraseña',
    'phone' => 'Teléfono',
    'interested_in' => 'Programa de Interés',
    'source' => 'Dónde te enteraste',
    'ciudad' => 'Selecciona tu region',
    'lc' => 'Entidad Local',
    'thank-you-message' => 'Muchas gracias por tu registro, pronto recibirás un correo electónico. E inicia sesion en nuestra  <a href="https://opportunities.aiesec.org/" target="_blank"> plataforma.</a>',
    'country_name' => 'Chile',
    'mc_id' => '1566'
);

?>