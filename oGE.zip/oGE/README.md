/*
Plugin Name: AIESEC EXPA Registration 
Description: Plugin based on gis_curl_registration script by Dan Laush upgraded to Wordpress plugin
Version: 0.2
Author: Enrique Suarez
//Version: 0.1
//Author: Krzysztof Jackowski
//Author URI: https://www.linkedin.com/profile/view?id=202008277&trk=nav_responsive_tab_profile_pic
License: GPL 
THis version is now linked with podio 
*/

To adpot EXPA Wordpress plugin for your website you need to do following:
1) Go to config.php file and edit basic labels for the form, thank you message and data about your entity from EXPA
2) Go to leads.json file and put there all your leads assigned to LCs that you have on EXPA. LC name MUST be the same as on EXPA!
3) Go to lc_id.json file and set all LCs in your entity with valid EXPA id

DO NOT CHANGE STRUCTURE OF JSON FILE!

Your plugin is configured and ready to go :) Now all you need to do is to install plugin in your Wordpress instalation on server. 
To put form on your website use shortcode: [expa-form]

Enjoy working with the plugin. If you have any inputs feedback is highly appreciated. In any case please send me e-mail: enrique.suarez@aiesec.net
//Enjoy working with the plugin. If you have any inputs feedback is highly appreciated. In any case please send me e-mail: krzysztof.jackowski@aiesec.net

AIESECly yours
Kris and Enrique